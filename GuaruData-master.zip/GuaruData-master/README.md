# GuaruData
Repositório com dados municipais de Guarulhos
