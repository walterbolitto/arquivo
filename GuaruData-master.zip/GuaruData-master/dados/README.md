Nesta pasta você encontra dados de Guarulhos no formato CSV e GeoJSON.
