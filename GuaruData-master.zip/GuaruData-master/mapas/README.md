Nesta pasta você encontra mapas de Guarulhos com dados estatísticos por bairro, contendo o mapa de diversos indicadores em formato de imagem para utilização e a planilha com os dados utilizados.


Fontes: 

-IBGE. Censo Demográfico 2010 – Resultados Preliminares do Universo. Rio de Janeiro: IBGE, 2011.

-OLIVEIRA, A. M. S.; ANDRADE, M. R. M.; SATO, E. S.; QUEIROZ, W. Bases Geoambientais para um Sistema de Informações Ambientais do Município de Guarulhos. Guarulhos: Laboratório de Geoprocessamento da Universidade Guarulhos, 2009. 178 p. 4v. Mapas (Relatório FAPESP - Processo 05/57965-1).

-TORRESANI, Bruna Daniele de Carvalho Gimenez et al. ANÁLISE DA COBERTURA ARBÓREA NO MUNICÍPIO DE GUARULHOS (SP), COMO UM DOS INDICADORES DA VARIAÇÃO DE TEMPERATURA SUPERFICIAL E DA QUALIDADE AMBIENTAL. Revista Geociências-UNG, v. 15, n. 2, p. 94-105, 2016.
