Para a realização da análise espacial de dados do município de Guarulhos, principalmente com o objetivo de usar dados do IBGE de 2010, deve-se tomar cuidado com a divisão territorial do município, já que existe conflitos em relação aos limites municipais na região do Cabuçu e da retificação do Tietê, fazendo com que os dados do IBGE não sejam equivalentes aos do Portal de Geoprocessamento de Guarulhos (GuaruGeo). 

Esta pasta busca armazenar dados georeferenciados com o esforço de reunir informações de município.

# Conteúdo

## Bairros
Esta pasta corrige os bairros dos setores censitários do município de Guarulhos no censo de 2010 do IBGE, contendo um arquivo .csv e o shape já com a informação.
